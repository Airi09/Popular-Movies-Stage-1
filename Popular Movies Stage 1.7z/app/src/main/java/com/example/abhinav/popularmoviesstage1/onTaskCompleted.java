package com.example.abhinav.popularmoviesstage1;


interface OnTaskCompleted {
    void onFetchMoviesTaskCompleted(Movie[] movies);
}
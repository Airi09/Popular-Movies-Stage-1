package com.example.abhinav.popularmovies;

interface OnTaskCompleted {
    void onFetchMoviesTaskCompleted(MovieInfo[] movies);
}
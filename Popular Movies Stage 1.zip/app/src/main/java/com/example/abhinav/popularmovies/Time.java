package com.example.abhinav.popularmovies;

import android.content.Context;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
public class Time {
    private static Date getDate(String date, String format) throws ParseException {
        SimpleDateFormat Format = new SimpleDateFormat(format);

        return Format.parse(date);
    }

    /*
     * Based on code from http://stackoverflow.com/a/11093572
     */
    public static String getLocalDate(Context context, String date, String format)
            throws ParseException {
        DateFormat dateFormat = android.text.format.DateFormat.getDateFormat(context);

        return dateFormat.format(getDate(date, format));
    }
}
